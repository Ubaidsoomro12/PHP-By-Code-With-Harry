<?php
include 'dbconnect.php';
$showalert = false;
$erroralert = false;

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all fields are set in the POST request
    if (isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["cpassword"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $cpassword = $_POST["cpassword"];

        // Check if password matches confirm password
        if ($password == $cpassword) {
            // Insert the data if passwords match
            $sql = "INSERT INTO `user` ( `username`, `password`, `date`) VALUES ('$username', '$password', current_timestamp())";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                $showalert = true;
            }
        } else {
            // Set error alert if passwords do not match
            $erroralert = "Passwords do not match";
        }
    } 
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUP</title>
    <style>
    .F {
        max-width: 500px;
        margin: auto;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        background-color: #f2f2f2;
        text-align: center;
        font-family: Arial, sans-serif;
        font-size: 16px;
        line-height: 24px;
        color: #333;
        transition: all 0.3s ease-in-out;

    }
    </style>
</head>

<body>
    <?php require 'navebar.php' ?>
    <!-- Alert show when our $showalert variable is true -->
    <?php
        if($showalert){    
    echo'
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Successfull!</strong> Your account is now created and you can login.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
        if($erroralert){    
    echo'
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Successfull!</strong> '.$erroralert.'.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    }
    ?>
    <div class="container">
        <br>
        <h1 class="text-center ">SignUp to our Website</h1>
        <!-- Form start here -->
        <form class="F" action="/php/loginsystem/Signup.php" method="post">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" aria-describedby="emailHelp" name="username">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <div class="mb-3">
                <label for="cpassword" class="form-label">Confrim Password</label>
                <input type="password" class="form-control" id="cpassword" name="cpassword">
                <div id="emailHelp" class="form-text">Make sure to type tha same password</div>

            </div>

            <button type="submit" class="btn btn-primary">SignUp</button>
        </form>

    </div>

</body>

</html>