    <?php
    require 'dbconnect.php';
    $login = false;
    $erroralert = false;

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];
    
            // Run the query to match the variable and database are same. ?

            $sql = "SELECT * FROM `user` WHERE `username` = '$username' AND `password` = '$password' ";
            $result = mysqli_query($conn, $sql);
            
            // Check if the username and password match
            if(mysqli_num_rows($result) > 0) {
                $login = true;
                //Session start here
                session_start();
                $_SESSION['login'] = true;
                $_SESSION['username'] = $username;
                header("location: welcome & Logout.php");
               
              
            } else {
                $erroralert = "Password Are Invalid";
            }
          
        }

    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SignUP</title>
        <style>
        .F {
            max-width: 500px;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #f2f2f2;
            text-align: center;
            font-family: Arial, sans-serif;
            font-size: 16px;
            line-height: 24px;
            color: #333;
            transition: all 0.3s ease-in-out;

        }
        </style>
    </head>

    <body>
        <?php require 'navebar.php' ?>
        <!-- Alert show when our $login variable is true -->
        <?php
            if($login){    
        echo'
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Successfull!</strong> You successfully logged in.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
            if($erroralert){    
        echo'
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Successfull!</strong> '.$erroralert.'.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        }
        ?>
        <div class="container" >
            <br>
            <h1 class="text-center ">LogIn</h1>
            <!-- Form start here -->
            <form class="F" action="/php/loginsystem/Login.php" method="post">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" aria-describedby="emailHelp" name="username">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>
                

                <button type="submit" class="btn btn-primary">LogIn</button>
            </form>

        </div>

    </body>

    </html>