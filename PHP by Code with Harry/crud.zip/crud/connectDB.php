<?php
// Define database path
$servername = "localhost"; 
$username = "root"; 
$password = "";
$dbname = "crudoperation"; // now here we specify database name because we use specific database for create inside the table. 

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname); 

// Check connection 
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error()); 
  
}

?>