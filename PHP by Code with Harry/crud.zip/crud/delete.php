<?php
//  ------------ Fist we connect database ---------------
include 'connectDB.php';

//get the URL using $_GET variable and give it name which i use delete button and store in $id variable
if(isset($_GET['deleteid'])){
    $id = $_GET['deleteid'];
    $sql = "DELETE FROM `crud` WHERE s_no=$id";
    $result=mysqli_query($conn, $sql);
    
    if($result){
        header('location: read.php'); //redirect to read.php after delete operation
    }else{
        echo "Error: ". mysqli_error($conn); //print error if any
    }
}

?>