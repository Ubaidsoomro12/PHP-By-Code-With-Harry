<?php

include 'connectDB.php';

// Retrieve the ID from the URL
$id = $_GET['updateid'];

//last stap when we update the data show all field in the update form.
$sql="SELECT * FROM `crud` WHERE s_no=$id";
$result=mysqli_query($conn,$sql);
// now using this method i can access tha data from my database.
    $row = mysqli_fetch_assoc($result); 
            $name=$row['name'];
            $email=$row['email'];
            $phone=$row['mobile'];
            $password=$row['pass'];

?>
<!DOCTYPE html>
<html lang="en">
<head>

<?php
$row = mysqli_fetch_assoc($result);

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['mobile'];
    $password = $_POST['pass'];

    // Prepare the SQL query with correct syntax
    $sql = "UPDATE `crud` SET `name`='$name', `email`='$email', `mobile`='$phone', `pass`='$password' WHERE `s_no` = '$id'";
    
    // Execute the query
    $result = mysqli_query($conn, $sql);
    
    if ($result) {
        // echo "Updated successfully";
        header('location: read.php'); // Redirect to read.php after update operation
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>PHP CRUD</title>
    <style>
        .form {
            max-width: 500px;
            margin: auto;
            margin-top: 50px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #f9f9f9;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .form label {
            font-size: 16px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    
    <!-- Form start here -->
    <form class="form" method="post" action="">
        <div class="mb-3">
            <label for="name" class="form-label">Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter your name" name="name" required value=<?php echo $name  ?>>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter your email" name="email" required value=<?php echo $email  ?>>
        </div>
        <div class="mb-3">
            <label for="mobile" class="form-label">Mobile:</label>
            <input type="number" class="form-control" id="mobile" placeholder="Enter your mobile number" name="mobile" required value=<?php echo $phone  ?>>
        </div>
        <div class="mb-3">
            <label for="pass" class="form-label">Password:</label>
            <input type="password" class="form-control" id="pass" placeholder="Enter your password" name="pass" required value=<?php echo $password  ?>>
        </div>
        
        <button type="submit" class="btn btn-primary" name="submit">UPDATE</button>
    </form>

    <!-- Form End here -->
</body>

</html>
