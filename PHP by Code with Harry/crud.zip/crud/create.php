
<?php

include 'connectDB.php';

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['mobile'];
    $password = $_POST['pass'];

    $sql = "INSERT INTO `crud` (name, email, mobile, pass) VALUES ('$name', '$email', '$phone', '$password')";

    $result = mysqli_query($conn, $sql);
    
    if($result){
        // echo "New record created successfully";
        header('location:read.php');
    }else{
        echo "Error: ". mysqli_error($conn);

    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>PHP CRUD</title>
    <style>
.form{
    max-width: 500px;
    margin: auto;
    margin-top:50px;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #f9f9f9;
    overflow: hidden;
    transition: all 0.3s ease;
}
.form label{
    font-size: 16px;
    font-weight: bold;
}
</style>
</head>

<body>
    
    <!-- Form start here  -->
    <form class="form" method="post" action="create.php">
        <div class="mb-3 ">
            <label for="#" class="form-label">Name:</label>
            <input type="text" class="form-control" id="#"  placeholder="Enter your name" name="name">
            
        </div>
        <div class="mb-3 ">
            <label for="#" class="form-label">Email:</label>
            <input type="email" class="form-control" id="#"  placeholder="Enter your email" name="email">
            
        </div>
        <div class="mb-3 ">
            <label for="#" class="form-label">Mobile:</label>
            <input type="number" class="form-control" id="#"  placeholder="Enter your monile number" name="mobile">
            
        </div>
        <div class="mb-3">
            <label for="#" class="form-label">Password:</label>
            <input type="password" class="form-control" id="#" placeholder="Enter your password" name="pass">
        </div>
        
        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
    </form>

    <!-- Form End here  -->
</body>

</html>