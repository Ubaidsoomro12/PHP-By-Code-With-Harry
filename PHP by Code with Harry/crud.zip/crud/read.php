<?php
include 'connectDB.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>PHP CRUD</title>
</head>

<body>

    <div class="container">
        <button class="btn btn-primary btn-lg my-5"><a href="create.php" class="text-light">ADD User</a></button>
        <!-- Table start here -->
        <table class="table table-success table-striped">
            <thead>
                <tr>
                    <th scope="col">S_no</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Password</th>
                    <th scope="col">Operation</th>
                </tr>
            </thead>

            <tbody>
                <?php
    $sql="SELECT * FROM `crud`";
    $result=mysqli_query($conn,$sql);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
            $s_no=$row['s_no'];
            $name=$row['name'];
            $email=$row['email'];
            $phone=$row['mobile'];
            $password=$row['pass'];
            
            // now i want to print data in table form
             echo '
             <tr>
              <td>'.$s_no.'</td>
              <td>'.$name.'</td>
              <td>'.$email.'</td>
              <td>'.$phone.'</td>
              <td>'.$password.'</td>
              
                <td>
                <button class="btn btn-primary"><a href="update.php?updateid='.$s_no.'" class="text-light">UPDATE</a></button>
                <button class="btn btn-danger"><a href="delete.php?deleteid='.$s_no.'" class="text-light">DELETE</a></button>
                </td>
            </tr> 
             ';
             // here i want delete row data inside table so i want perticuler id for identifying tha data wich i can deleting so i use ?deleteid='.$id.'(YOU CAN GIVE ANY NAME HEREW) after delete.php. so i want to pass id in delete.php page so i can delete perticuler row data from table.

        }
    }
    ?>
            </tbody>

        </table>
        <!-- Table end here -->
    </div>

</body>

</html>