<?php
// ------------------------------------- The fopen() function opens a file or URL --------------------------

$fo = fopen("file.txt","r");
if($fo){
    echo "File opened successfully";
}else{
    echo "Error opening file";
 
}

echo"<br>";

// ------------------------------------- The fread() function reads a file ---------------------------

$data = fread($fo, filesize("file.txt"));

// ------------------------------------- The fclose() function closes a file -------------------------

fclose($fo);

echo $data;



?>