<?php
// ----------- ------------The fgets() function returns a line from an open file. ---------------

//-------------- Open a file for reading -----------------------
$Read_line = fopen("file.txt","r");
// echo fgets($Read_line); // print line one 
// echo"<br>";
// echo fgets($Read_line); // print line two
// echo"<br>";
// echo fgets($Read_line); // print line three

// print each line using while loop
// while($a = fgets($Read_line)){
//     echo $a; // print each line of file
//     echo "<br>";

// }


// ------------ The fgetc() function returns a single character from an open file.-----------------------
//  $Read_char = fopen("file.txt","r");
 // echo fgetc($Read_char); // print only one character in file
 // echo fgetc($Read_char); // print only one character in file


// print each characters using while loop
//  while($a = fgetc($Read_line)){
//         echo $a; // print each line of file
//          echo "<br>";
    
//      }

// just firexample if i want to print specific condition like when you see full stop you please breack code.
$Read_char = fopen("file.txt","r");

 while($a = fgetc($Read_line)){
    echo $a;
    if($a == "."){
        break;
    }

 }
 



?>