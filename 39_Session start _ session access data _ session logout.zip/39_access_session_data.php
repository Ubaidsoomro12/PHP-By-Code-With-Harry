<?php

// start the session and get tha data into another page.

session_start();

// echo "Welcome ".$_SESSION['username'];
// echo "<br>Your favriout color is  ".$_SESSION['favcolor'];
// echo "<br>And your favriout animal is ".$_SESSION['favanimal'];

// handle the error if user does not match user name.

if(isset($_SESSION['username'])){
    echo "Welcome ".$_SESSION['username'];
    echo "<br>Your favriout color is  ".$_SESSION['favcolor'];
    echo "<br>And your favriout animal is ".$_SESSION['favanimal'];

}else{
    echo "Error: User not found";
}
?>