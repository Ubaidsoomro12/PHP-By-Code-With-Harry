<?php



session_start();

//logout
session_unset(); // The unset() function unsets a variable.
session_destroy(); // session_destroy() destroys all of the data associated with the current session.
echo "<br>You have been logged out";


?>